//
//  ColorTheme.swift
//  WheatherAppSwiftUI
//
//  Created by Yogini Unde on 11/05/24.
//

import SwiftUI

struct ColorTheme: View {
    @Environment(\.colorScheme) var current
    @State private var showModal = false
    @EnvironmentObject var csManager: ColorSchemeManager
    var body: some View {
        NavigationView {
            VStack {
                Picker("", selection: $csManager.colorScheme) {
                    Text(Constants.dark).tag(ColorScheme.dark)
                    Text(Constants.light).tag(ColorScheme.light)
                    Text(Constants.system).tag(ColorScheme.unspecified)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()
                Button(action: {
                    showModal.toggle()
                }) {
                   // Text("Show Modal")
                }
               Spacer()
            }
        //.sheet(isPresented: $showModal) {
        //  Text("")
        //}
                    //.navigationTitle(Constants.selectTheme)
            .navigationTitle("")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ColorTheme()
            .environmentObject(ColorSchemeManager())
    }
}
