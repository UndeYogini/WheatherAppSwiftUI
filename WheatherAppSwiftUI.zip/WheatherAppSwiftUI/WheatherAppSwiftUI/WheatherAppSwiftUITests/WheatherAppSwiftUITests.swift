//
//  WheatherAppSwiftUITests.swift
//  WheatherAppSwiftUITests
//
//  Created by Yogini Unde on 07/05/24.
//

import XCTest

@testable import WheatherAppSwiftUI

final class WheatherAppSwiftUITests: XCTestCase {
    
    var apiClient: MockableHttpClient!
    var wm = AddWeatherViewModel()
    private var store: Store!

    override func setUp() {
        super.setUp()
        wm = AddWeatherViewModel()
        apiClient = MockableHttpClient()

    }
    
    override func tearDown() {
        super.tearDown()
        //wm = nil
    }
    
    // Test initial state of products
    func test_initial_state_has_empty_products() {
        XCTAssertEqual(wm.products.count, 0)
    }
    
    func test_get_request_withURL() {
        guard Constants.Urls.weatherByCity(city: Constants.testCity) != nil else {
            fatalError(Constants.emptyURL)
        }
    }
    
    func  test_fetchdata_successfully() async throws{

        _ = XCTestExpectation(description: Constants.fetchprodlist)
        
        wm.save { [self]  weather in
            store.addWeather(weather)
        }
    
    }
    
    
}
