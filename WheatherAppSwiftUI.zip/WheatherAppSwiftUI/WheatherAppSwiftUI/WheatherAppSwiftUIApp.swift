//
//  WheatherAppSwiftUIApp.swift
//  WheatherAppSwiftUI
//
//  Created by Yogini Unde on 06/05/24.
//

import SwiftUI

@main
struct WheatherAppSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            WeatherListScreen().environmentObject(Store())
            //ContentView()
        }
    }
}
