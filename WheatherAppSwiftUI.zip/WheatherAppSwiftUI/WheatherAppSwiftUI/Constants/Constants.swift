//
//  Constants.swift
//  WheatherAppSwiftUI
//
//  Created by Yogini Unde on 06/05/24.
//

import Foundation

struct Constants {
    struct Urls {
        static func weatherByCity(city: String) -> URL? {
            // get the default settings for temperature
            let userDefaults = UserDefaults.standard
            let unit = (userDefaults.value(forKey: "unit") as? String) ?? "imperial"
            return URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(city.escaped())&appid=d05b3e6c4549e172e4908b26a386f8b0&units=metric")!
        }
        
    }
    static let selectTheme = "Select Theme"
    static let dark = "Dark"
    static let light = "Light"
    static let system = "System"
    static let selectTempUnit = "Select temperature unit?"
    static let setting = "Settings"
    static let celsius =  "Celsius"
    static let fahrenheit = "Fahrenheit"
    static let gearshape = "gearshape"
    static let plus = "plus"
    static let cities = "Cities"
    static let enterCityPlaceholder = "Enter city"
    static let save = "Save"
    static let addCity = "Add city"
    static let unit = "unit"
    static let colorScheme = "colorScheme"
    static let dateformat = "hh:mm a"
    
    // Accessibility VoiceOver Text
    static let addcityLabel = "Add City"
    static let settingsLabel = "Settings"
    static let city = "City"
    static let temprature = "Temprature"
    static let testCity = "Pune"
    static let changeColorTheme = "Change Color Theme"
    static let done = "Done"
    static let saveWeatherDetails = "Save Weather Details"
    
    // Network Error Messages
    static let WeatherListResponse = "WeatherListResponse"
    static let emptyURL = "URL can't be empty"
    static let fetchprodlist = "Fetched Product List"



}
